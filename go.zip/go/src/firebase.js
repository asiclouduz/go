import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  // Replace with your Firebase configuration
  apiKey: "AIzaSyB5Pm6brEmDIkfYGgHOX5RD4jMmpyVaknU",
  authDomain: "nexuscoin-7ed6b.firebaseapp.com",
  projectId: "nexuscoin-7ed6b",
  storageBucket: "nexuscoin-7ed6b.appspot.com",
  messagingSenderId: "547958321097",
  appId: "1:547958321097:web:0aa6d26bc0a7a45f8b4218"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export { auth, db };
